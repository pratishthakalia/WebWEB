// const projectData = require("../data/projectData");
// const sectorData = require("../data/sectorData");

require('dotenv').config();
require('pg');
const Sequelize = require('sequelize');

const isSSL = process.env.USE_SSL === 'true';

const sequelize = new Sequelize(
    process.env.PGDATABASE,
    process.env.PGUSER,
    process.env.PGPASSWORD,
    {
        host: process.env.PGHOST,
        dialect: 'postgres',
        port: 5432,
        dialectOptions: { ssl: { rejectUnauthorized: false } },
    }
);

sequelize
  .authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch((err) => {
    console.log('Unable to connect to the database:', err);
  });

let projects = [];


const Sector = sequelize.define(
    'Sector', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true 
        },
        sector_name: Sequelize.STRING 
    },
    {
        createdAt: false,
        updatedAt: false 
    }
);
const Project = sequelize.define(
    'Project', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true 
        },
        title: Sequelize.STRING,
        feature_img_url: Sequelize.STRING,
        summary_short: Sequelize.TEXT, 
        Intro_short: Sequelize.TEXT,
        original_source_url: Sequelize.STRING
    },
    {
        createdAt: false,
        updatedAt: false
    }
);

function initialize() {
  return new Promise((resolve, reject) => {
    // projectData.forEach(projectElement => {
    //   let projectWithSector = { ...projectElement, sector: sectorData.find(sectorElement => sectorElement.id == projectElement.sector_id).sector_name }
    //   projects.push(projectWithSector);
    // });
    // resolve();
    sequelize.sync()
        .then(() => resolve())
        .catch((err) => reject(`Unable to sync the database: ${err.message}`));
  });
}

function getAllProjects() {
  return new Promise((resolve, reject) => {
    Project.findAll({ include: [Sector]})
    .then((projects) => resolve(projects))
    .catch((err) => reject(`Unable to retrieve projects: ${err.message}`))
  });
}

function getProjectById(projectId) {
  return new Promise((resolve, reject) => {
    // let foundProject = projects.find(p => p.id == projectId);

    // if (foundProject) {
    //   resolve(foundProject)
    // } else {
    //   reject("Unable to find requested project");
    // }
    Project.findOne({ where: { id: projectId }, include: [Sector] })
    .then((project) => {
        if (project) {
            resolve(project);
        } else {
            reject(`Unable to find project with ID: ${projectId}`);
        }
    })
    .catch((err) => reject(`Error retrieving project: ${err.message}`));
  });

}

function getProjectsBySector(sector) {
  return new Promise((resolve, reject) => {
  //   let foundProjects = projects.filter(p => p.sector.toUpperCase().includes(sector.toUpperCase()));

  //   if (foundProjects) {
  //     resolve(foundProjects)
  //   } else {
  //     reject("Unable to find requested projects");
  Project.findAll({
    include: [Sector],
    where: {
        '$Sector.sector_name$': {
            [Sequelize.Op.iLike]: `%${sector}%`
        }
    }
})
.then((projects) => {
    if (projects.length > 0) {
        resolve(projects);
    } else {
        reject(`No projects found for sector: ${sector}`);
    }
})
.catch((err) => reject(`Error retrieving projects: ${err.message}`));

});

}

function addProject(projectData) {
  return new Promise((resolve, reject) => {
      Project.create(projectData)
          .then(() => resolve())
          .catch(err => reject(`Unable to add project: ${err.errors[0].message}`));
  });
}

function getAllSectors() {
  return new Promise((resolve, reject) => {
      Sector.findAll()
          .then(sectors => resolve(sectors))
          .catch(err => reject(`Unable to retrieve sectors: ${err.message}`));
  });
}

function editProject(id, projectData) {
  return new Promise((resolve, reject) => {
      Project.update(projectData, { where: { id } })
          .then(() => resolve())
          .catch(err => reject(`Unable to update project: ${err.errors[0].message}`));
  });
}

function deleteProject(id) {
  return new Promise((resolve, reject) => {
      Project.destroy({ where: { id } })
          .then(() => resolve())
          .catch(err => reject(`Unable to delete project: ${err.message}`));
  });
}



module.exports = { initialize, getAllProjects, getProjectById, getProjectsBySector, addProject, getAllSectors, editProject, deleteProject }


