/********************************************************************************
* BTI325 – Assignment 05
*
* I declare that this assignment is my own work in accordance with Seneca's
* Academic Integrity Policy:
*
* https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
*
* Name: Punya Pratishtha Kalia Student ID: 181480211 Date: 03 November 2024
*
********************************************************************************/
const projectData = require("./modules/projects")
const path = require("path")

const express = require('express')
const app = express()
app.set('view engine', 'ejs')
app.set('views', __dirname + '/views');

const HTTP_PORT = process.env.PORT || 3000
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true })); // Middleware 

// Render the form
app.get('/solutions/addProject', async (req, res) => {
    try {
        const sectors = await projectData.getAllSectors();
        res.render('addProject', { sectors });
    } catch (err) {
        res.status(500).render(path.join(__dirname, "/views/500.ejs", { message: "Unable to load the form. Please try again." }));
    }
});

app.post('/solutions/addProject', async (req, res) => {
    try {
        await projectData.addProject(req.body);
        res.redirect('/solutions/projects'); // Redirect to project list after successful insertion
    } catch (err) {
        res.status(500).render(path.join(__dirname, "/views/500.ejs", { message: `Unable to add the project: ${err.message}` }));
    }
});

// Render the edit form
app.get('/solutions/editProject/:id', async (req, res) => {
  try {
      const project = await projectData.getProjectById(parseInt(req.params.id));
      const sectors = await projectData.getAllSectors();
      res.render('editProject', { project, sectors });
  } catch (err) {
      res.status(404).render(path.join(__dirname, "/views/404.ejs", { message: `Unable to find project with ID: ${req.params.id}` }));
  }
});

//  Process the edit form
app.post('/solutions/editProject', async (req, res) => {
  try {
      await projectData.editProject(req.body.id, req.body);
      res.redirect('/solutions/projects'); // Redirect to projects list after successful update
  } catch (err) {
      res.status(500).render(path.join(__dirname, "/views/500.ejs", { message: `Unable to update the project: ${err.message}` }));
  }
});

//delete project
app.get('/solutions/deleteProject/:id', async (req, res) => {
  try {
      await projectData.deleteProject(parseInt(req.params.id));
      res.redirect('/solutions/projects'); 
  } catch (err) {
      res.status(500).render(path.join(__dirname, "/views/500.ejs", { message: `Unable to delete the project: ${err.message}` }));
  }
});

app.get("/", (reg, res) => {
    res.render(path.join(__dirname, '/views/home.ejs'))
});

app.get("/about", (reg, res) => {
    res.render(path.join(__dirname, '/views/about.ejs'))
});

app.get("/solutions/projects", async (req, res) => {
    try {
      let data;
      if (Object.keys(req.query).length === 0) {
        data = await projectData.getAllProjects();
      } else if (req.query.sector === "Land Sinks") {
        data = await projectData.getProjectsBySector("Land Sinks");
      } else if (req.query.sector === "Industry") {
        data = await projectData.getProjectsBySector("Industry");
      } else if (req.query.sector === "Transportation") {
        data = await projectData.getProjectsBySector("Transportation");
      } else {
        throw new Error("Invalid sector");
      }
      res.render(path.join(__dirname, "/views/projects.ejs"), {
        projects: data,
      });
    } catch (error) {
      console.log(error.message);
      res.status(404).render(path.join(__dirname, "/views/404.ejs"), {
        message: `No projects found for sector: ${req.query.sector}.`,
      });
    }
  });
  
  app.get("/solutions/projects/:id", async (req, res) => {
    try {
      let data = await projectData.getProjectById(parseInt(req.params.id));
      res.render(path.join(__dirname, "/views/project.ejs"), {
        project: data,
      });
    } catch (error) {
      res.status(404).render(path.join(__dirname, "/views/404.ejs"), {
        message: "Unable to find requested project.",
      });
    }
  });
  
projectData.initialize().then(()=> {
    app.listen(HTTP_PORT, () => { console.log(`server listening on: ${HTTP_PORT}`) });
});
